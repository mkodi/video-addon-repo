# -*- coding: utf-8 -*-
# Module: default
# Author: M.K.
# Created on: 12.23.2020
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
import os
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import logging
import json
# import urllib.request
import urllib2
from urllib2 import HTTPError, URLError
import xml.etree.ElementTree as ET

# Get addon
__addon__ = xbmcaddon.Addon()
# __profile__ would be "userdata/addon_data/<your addon ID>"
__profile__ = xbmc.translatePath(__addon__.getAddonInfo('profile')).decode("utf-8")

# import livestreamer
# from livestreamer import Livestreamer, StreamError, PluginError, NoPluginError

# params = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/602.2.14 (KHTML, like Gecko) Version/10.0.1 Safari/602.2.14', 'Referer': 'http://tvshqip.tv/channel/tv-klan-live/tvplayer.swf'}
# livestrm = Livestreamer()

# streams = livestrm.streams('http://tvshqip.tv/stream/channel_183.m3u8?token=f2f57aa1e7268b9487ca9b6cecac0e82', params)
# xbmc.log(streams)

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

# Free sample videos are provided by www.vidsplay.com
# Here we use a fixed set of properties simply for demonstrating purposes
# In a "real life" plugin you will need to get info and links to video files/streams
# from some web-site or online service.
addon = xbmcaddon.Addon('plugin.video.livetv')
home = xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8'))
# __profile__ would be "userdata/addon_data/<your addon ID>"
profile = xbmc.translatePath(addon.getAddonInfo('profile').decode("utf-8"))

generalImage = os.path.join(home, 'resources/media/images', 'general.jpg')
imagesPath = os.path.join(home, 'resources/media/images')

# Initial value for awsEc2Url
awsEc2Url = 'http://127.0.0.1:8080'

try:
    # tree = ET.parse('/Users/mk/Library/Application Support/Kodi/userdata/addon_data/plugin.video.livetv/settings.xml')
    tree = ET.parse('%ssettings.xml' % profile)
    # Get root tag ex. settings
    root = tree.getroot()
    # Find all children tags ('setting') under settings root tag in settings.xml
    for type_tag in root.findall('setting'):
        if type_tag.get('id') == 'ipaddress':
            awsEc2Url = 'http://%s' % type_tag.text
except IOError as e:
    print('IO error in parsing the settings file from addon userdata: %s' % e)

# Get config data from file
configTiboFile = json.load(open('%s/resources/data/config.json' % home))

# Get config data from remote server
fetchedTiboConfigJSON = ''
request = urllib2.Request('%s/tibo/config' % awsEc2Url)
try:
    response = urllib2.urlopen(request, timeout=3.2)
    fetchedTiboConfigJSON = response.read()
except HTTPError as error:
    print('HTTP error in request for tibo config: %s' % error)
except URLError as e:
    print('We failed to reach a server. Reason: %s' % e.reason)

fetchedTiboConfig = {}
try:
    fetchedTiboConfig = json.loads(fetchedTiboConfigJSON)
except ValueError as e:
    print('Invalid JSON in request for tibo config: %s' % e)

xbmc.log('generalImage is ' + generalImage)

# Python 3
# req = urllib.request.Request('%s/albtvonline/channels' % awsEc2Url)
# with urllib.request.urlopen(req) as response:
# fetchedChannels = response.read()


# Get config data from remote server for albtv online channels
fetchedAlbTVConfigJSON = ''
request = urllib2.Request('%s/albtvonline/config' % awsEc2Url)
try:
    response = urllib2.urlopen(request, timeout=3.2)
    fetchedAlbTVConfigJSON = response.read()
except HTTPError as error:
    print('HTTP error in request for tibo config: %s' % error)
except URLError as e:
    print('We failed to reach a server. Reason: %s' % e.reason)

fetchedAlbTVConfig = {}
try:
    fetchedAlbTVConfig = json.loads(fetchedAlbTVConfigJSON)
except ValueError as e:
    print('Invalid JSON in request for albtv config: %s' % e)


def get_image(main_path, image, type):
    image_path = '%s/%s.%s' % (main_path, image.lower(), type)
    return image_path


def get_channels(channels, subscription):
    list_channels = []
    keys = channels.keys()
    for i in range(len(keys)):
        channel = {}
        tibo_path = '%s/%s/%s/%s.m3u8' % (awsEc2Url, subscription, keys[i], keys[i])
        albtv_path = '%s' % channels[keys[i]]['url']
        video_path = tibo_path if subscription == 'tibo' else albtv_path

        channel['name'] = channels[keys[i]]['name']
        channel['thumb'] = get_image(imagesPath, channels[keys[i]]['genre'], 'png')
        channel['video'] = video_path
        channel['genre'] = channels[keys[i]]['genre'].title()  # capitalize each word
        list_channels.append(channel)
    return list_channels


# Example
# VIDEOS = {'General': [{'name': 'Klan',
#                        'thumb': '%s' % klanImage,
#                        # 'video': '%s/173.69.194.169/1490471648/30/klanTV.m3u8' % digitalbLink,
#                        'video': '%s/klan.m3u8' % awsEc2Url,
#                        'genre': 'General'},
#                       {'name': 'TopChannel',
#                        'thumb': '%s' % topImage,
#                        # 'video': '%s/173.69.194.169/1490471556/27/Tch/Tch.m3u8' % digitalbLink,
#                        'video': '%s/topchannel.m3u8' % awsEc2Url,
#                        'genre': 'General'}
#                       ]
#                     ]}
#

VIDEOS = {
    'Tibo': get_channels(configTiboFile['tibo']['channels'], 'tibo')
    if not fetchedTiboConfig
    else get_channels(fetchedTiboConfig['tibo']['channels'], 'tibo'),
    'AlbTV-Online': [
        {'name': 'Klan',
         'thumb': '%s' % generalImage,
         'video': 'http://79.106.48.2:4040/live/klanhdmob/playlist.m3u8',
         'genre': 'general'}]
    if not fetchedAlbTVConfig
    else get_channels(fetchedAlbTVConfig['albtv']['channels'], 'albtv')
}


def get_categories():
    """
    Get the list of video categories.
    Here you can insert some parsing code that retrieves
    the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
    from some site or server.
    :return: list
    """
    return VIDEOS.keys()


def get_videos(category, genre):
    """
    Get the list of videofiles/streams.
    Here you can insert some parsing code that retrieves
    the list of videostreams in a given category from some site or server.
    :param category: str
    :return: list
    """
    list_videos_by_genre = []
    for i in range(len(VIDEOS[category])):
        if VIDEOS[category][i]['genre'] == genre:
            list_videos_by_genre.append(VIDEOS[category][i])

    # return VIDEOS[category]
    return list_videos_by_genre


def get_genres(category):
    """
    Get the list of genres.
    :param category: str
    :return: list
    """
    list_genres = []
    set_genres = set()  # create a set of unique elements without duplicate
    for i in range(len(VIDEOS[category])):
        set_genres.add(VIDEOS[category][i]['genre'])
    for genre in set_genres:
        list_genres.append(genre)

    return list_genres


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    :return: None
    """
    # Get video categories
    categories = get_categories()
    # Create a list for our items.
    listing = []
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label.
        list_item = xbmcgui.ListItem(label=category)
        # Set a fanart image for the list item and a thumbnail image.
        list_item.setArt({'thumb': get_image(imagesPath, category, 'png'),
                          'fanart': get_image(imagesPath, category, 'jpg')})
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # http://mirrors.xbmc.org/docs/python-docs/15.x-isengard/xbmcgui.html#ListItem-setInfo
        list_item.setInfo('video', {'title': category, 'genre': category})
        # Create a URL for the plugin recursive callback.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = '{0}?action=listing_genre&category={1}'.format(_url, category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the listing as a 3-element tuple.
        listing.append((url, list_item, is_folder))
    # Add our listing to Kodi.
    # Large lists and/or slower systems benefit from adding all items at once via addDirectoryItems
    # instead of adding one by ove via addDirectoryItem.
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def list_genres(category):
    """
    Create the list of video categories in the Kodi interface.
    :return: None
    """
    # Get video genres
    genres = get_genres(category)
    # Create a list for our items.
    listing = []
    # Iterate through categories
    for genre in genres:
        # Create a list item with a text label.
        list_item = xbmcgui.ListItem(label=genre)
        # Set a fanart image for the list item and a thumbnail image.
        list_item.setArt({'thumb': get_image(imagesPath, genre, 'png'),
                          'fanart': get_image(imagesPath, genre, 'jpg')})
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # http://mirrors.xbmc.org/docs/python-docs/15.x-isengard/xbmcgui.html#ListItem-setInfo
        list_item.setInfo('video', {'title': category, 'genre': category})
        # Create a URL for the plugin recursive callback.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = '{0}?action=listing&category={1}&genre={2}'.format(_url, category, genre)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the listing as a 3-element tuple.
        listing.append((url, list_item, is_folder))
    # Add our listing to Kodi.
    # Large lists and/or slower systems benefit from adding all items at once via addDirectoryItems
    # instead of adding one by ove via addDirectoryItem.
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category, genre):
    """
    Create the list of playable videos in the Kodi interface.
    :param category: str
    :return: None
    """
    # Get the list of videos in the category.
    videos = get_videos(category, genre)
    # Create a list for our items.
    listing = []
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        list_item.setInfo('video', {'title': video['name'], 'genre': video['genre']})
        # Set a fanart image for the list item and thumbnail.
        # Set additional graphics (banner, poster, landscape etc.) for the list item.
        # Again, here we use the same image as the thumbnail for simplicity's sake.
        list_item.setArt({'landscape': video['thumb'],
                          'thumb': video['thumb'],
                          'fanart': get_image(imagesPath, genre, 'jpg')})
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for the plugin recursive callback.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/vids/crab.mp4
        url = '{0}?action=play&video={1}'.format(_url, video['video'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the listing as a 3-element tuple.
        listing.append((url, list_item, is_folder))
    # Add our listing to Kodi.
    # Large lists and/or slower systems benefit from adding all items at once via addDirectoryItems
    # instead of adding one by ove via addDirectoryItem.
    xbmcplugin.addDirectoryItems(_handle, listing, len(listing))
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def play_video(path):
    """
    Play a video by the provided path.
    :param path: str
    :return: None
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring
    :param paramstring:
    :return:
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'], params['genre'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        elif params['action'] == 'listing_genre':
            list_genres(params['category'])
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
